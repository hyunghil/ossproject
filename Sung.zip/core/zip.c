#include<stdio.h>
#include<stdilb.h>
#define MAX_PATH

int main()     // unzip and refind
{
	FILE *fd;
	int stat;
	int i=1;

	system("mkdir ZIP");  // creat ZIP directory
	
	system("unzip *.zip -d /home/ZIP"); // unzip *.zip in ZIP directory

	system("cd ZIP");

	if(val == no);
	{
		printf("File not exist");
	}
	fp = popen("find val.*","r");
	
	state = pclose(fp);
	return 0;


wq

